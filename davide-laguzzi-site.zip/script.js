const burger = document.getElementById("burger");
const menu = document.getElementById("mobileMenu");

function setMenu(open){
  burger?.setAttribute("aria-expanded", String(open));
  if (!menu) return;
  menu.style.display = open ? "block" : "none";
  menu.setAttribute("aria-hidden", String(!open));
}

burger?.addEventListener("click", () => {
  const isOpen = burger.getAttribute("aria-expanded") === "true";
  setMenu(!isOpen);
});

document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener("click", () => setMenu(false));
});
